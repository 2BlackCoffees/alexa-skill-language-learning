const Alexa = require('ask-sdk');

const i18next = require('i18next');
const i18nextSentences = require('i18next'); 
const SELECTED_LANGUAGE='selectedLanguage';



const TranslationService = {
    process(handlerInput) {
       i18next.init({
         lng: handlerInput.requestEnvelope.request.locale,
         resources: {
           "en-US": {
             translation: {
               "welcome": "Welcome to to foreign language learning! Please say language learning associated to the language you to learn, say help for more information.",
               "startLearning": "Please say in english the following sentence that I pronounce in <selectedLanguage>",
               "help": "Say my score to get your score. Say change language to learn another language. Currently only french and german are supported.",
               "failed": "Unfortunately, you said <saidSentence> but I was expecting <expectedSentence>",
               "succeeded": "Well done, here comes the next sentence in <selectedLanguage>",
               "cancel": "Good bye!",
               "myScore": "Your score is <succededTranslations> out of <trials>"
             }
          },
          "fr-FR": {
            translation: {
              "welcome": "Bienvenue à l'apprentissage de langues étrangères! Veuillez dire apprentissage de langue suivi de la langue que vous souhaitez apprendre,dites aide pour obtenir plus d'information.",
              "startLearning": "Attention c'est à vous, veuillez dire en francais la phrase suivante que je prononce en <selectedLanguage>",
              "help": "Dites mon score pour obtenir votre score. Dites, selectionnes une autre langue pour changer de langue. Actuellement seules les langues anglais et allemand peuvent être utilisées.",
              "failed": "Mahleureusement vous avez dit <saidSentence> mais je m'attendais à <expectedSentence>",
              "succeeded": "Bravo, voici la phrase suivante prononcée en <selectedLanguage>",
              "myScore": "Vous avez réussi à répondre correctement à <succededTranslations> traductions sur <trials>",
              "cancel": "Au revoir!"   
            }
          },
          "de-DE": {
            translation: {
              "welcome": "Bienvenue à l'apprentissage de langues étrangères! Veuillez dire apprentissage de langue suivi de la langue que vous souhaitez apprendre,dites aide pour obtenir plus d'information.",
              "startLearning": "Attention c'est à vous, veuillez dire en francais la phrase suivante que je prononce en <selectedLanguage>",
              "help": "Dites mon score pour obtenir votre score. Dites, selectionnes une autre langue pour changer de langue.",
              "failed": "Mahleureusement vous avez dit <saidSentence> mais je m'attendais à <expectedSentence>",
              "succeeded": "Bravo, voici la phrase suivante prononcée en <selectedLanguage>",
              "myScore": "Vous avez réussi à répondre correctement à <succededTranslations> traductions sur <trials>",
              "cancel": "Bis dann"
           }
            
         }
       }
       });
    }
};

function getLanguageCoding(language) {
    let language = 'en';
    if(language === 'french' || language === 'französisch') {
        language = 'fr';
    } else if(language === 'german' || language === 'allemand') {
        language = 'de';
    }
    return language;
}

const TranslationSentences = {
    process(handlerInput) {
        if(language in handlerInput.requestEnveloppe.request.intent.slots) {        
            const language = getLanguageCoding(handlerInput.requestEnveloppe.request.intent.slots.language.value);
            console.log("User selected language: ", language);
            i18nextSentences.init({
              lng: language,
              resources: {
                en: {
                  translation: {
                      "sentence1": "What’s up?",
                      "sentence2": "What have you been up to lately?",
                      "sentence3": "I’m fine, thanks. How about you?",
                      "sentence4": "Pretty good.",
                      "sentence5": "Same as always",
                      "sentence6": "Not so great.",
                      "sentence7": "Could be better",
                      "sentence8": "cant complain",
                      "sentence9": "I really appreciate it.",
                      "sentence10": "I’m really grateful",
                      "sentence11": "That’s so kind of you.",
                      "sentence12": "I owe you one. ",
                      "sentence13": "No problem.",
                      "sentence14": "No worries",
                      "sentence15": "Don’t mention it.",
                      "sentence16": "My pleasure.",
                      "sentence17": "Anytime.",
                      "sentence18": "It was nice chatting with you.",
                      "sentence19": "Anyway, I should get going.",
                      "sentence20": "Do you have any idea?",
                      "sentence21": "Would you happen to know where the station is? ",
                      "sentence22": "I don’t suppose you  know who is the president of the US?",
                      "sentence23": "I have no idea.",
                      "sentence24": "I can’t help you there.",
                      "sentence25": "Beats me.",
                      "sentence26": "I’m not really sure.",
                      "sentence27": "I’ve been wondering that, too.",
                      "sentence28": "I’ve never given it much thought.",
                      "sentence29": "I don’t have strong feelings either way.",
                      "sentence30": "It doesn’t make any difference to me.",
                      "sentence31": "I have no opinion on the matter.",
                      "sentence32": "Exactly.",
                      "sentence33": "Absolutely.",
                      "sentence34": "That’s so true.",
                      "sentence35": "That’s for sure.",
                      "sentence36": "I agree 100%",
                      "sentence37": "I couldn’t agree with you more.",
                      "sentence38": "Tell me about it!",
                      "sentence39": "I’ll say!",
                      "sentence40": "I suppose so. ",
                      "sentence41": "I’m not so sure about that.",
                      "sentence42": "That’s not how I see it.",
                      "sentence43": "Not necessarily",
                      "sentence44": "That’s great!",
                      "sentence45": "How wonderful!",
                      "sentence46": "Awesome!",
                      "sentence47": "Oh no",
                      "sentence48": "That’s terrible.",
                      "sentence49": "Poor you. ",
                      "sentence50": "I’m so sorry to hear that.",
                      "sentence51": "I’m starving! ",
                      "sentence52": "Let’s grab a bite to eat.",
                      "sentence53": "How about eating out tonight? "            
                  }
                },
                
                fr: {
                  translation: {
                      "sentence1": "Quoi de neuf?",
                      "sentence2": "Qu'avez-vous réalisé récemment?",
                      "sentence3": "Je vais bien merci. Et vous?",
                      "sentence4": "Assez bon.",
                      "sentence5": "Comme toujours",
                      "sentence6": "Pas si bien.",
                      "sentence7": "Cela pourrait être mieux",
                      "sentence8": "Je ne peux pas me plaindre",
                      "sentence9": "J'apprécie vraiment cela.",
                      "sentence10": "Je suis vraiment reconnaissant",
                      "sentence11": "C'est gentil de ta part.",
                      "sentence12": "Je t'en dois une. ",
                      "sentence13": "Aucun problème.",
                      "sentence14": "Pas de soucis",
                      "sentence15": "Ne le mentionne pas.",
                      "sentence16": "Mon plaisir.",
                      "sentence17": "À tout moment.",
                      "sentence18": "C'était sympa de bavarder avec vous.",
                      "sentence19": "Quoi qu'il en soit, je devrais y aller.",
                      "sentence20": "Avez-vous une idée?",
                      "sentence21": "Est-ce que tu saurais où se trouve la station?",
                      "sentence22": "Je suppose que vous ne savez pas qui est le président des États-Unis?",
                      "sentence23": "Je n'ai aucune idée.",
                      "sentence24": "Je ne peux pas vous aider là-bas.",
                      "sentence25": "Je me bat.",
                      "sentence26": "Je ne suis pas vraiment sûr.",
                      "sentence27": "Je me demandais cela aussi.",
                      "sentence28": "Je n'y ai jamais vraiment pensé.",
                      "sentence29": "Je n'ai pas de sentiments forts de toute façon.",
                      "sentence30": "Cela ne fait aucune différence pour moi.",
                      "sentence31": "Je n'ai pas d'opinion à ce sujet.",
                      "sentence32": "Exactement.",
                      "sentence33": "Absolument.",
                      "sentence34": "C'est tellement vrai.",
                      "sentence35": "C’est sûr.",
                      "sentence36": "Je suis d'accord à 100%",
                      "sentence37": "Je suis tout à fait d’accord avec vous.",
                      "sentence38": "Parle-moi de ça!",
                      "sentence39": "Je dirai!",
                      "sentence40": "Je suppose.",
                      "sentence41": "Je ne suis pas si sûr de ça.",
                      "sentence42": "Ce n'est pas comme ça que je le vois.",
                      "sentence43": "Pas nécessairement",
                      "sentence44": "C'est génial!",
                      "sentence45": "Merveilleux!",
                      "sentence46": "Impressionnant!",
                      "sentence47": "Oh non…",
                      "sentence48": "C'est terrible.",
                      "sentence49": "Pauvre toi.",
                      "sentence50": "Je suis désolé d'apprendre ça.",
                      "sentence51": "Je meurs de faim!",
                      "sentence52": "Prenons une bouchée à manger.",
                      "sentence53": "Que diriez-vous d'aller au restaurant ce soir?"          
                  }
                },
                de: {
                  translation: {
                      "sentence1": "Wie geht's?",
                      "sentence2": "Was hast du in letzter Zeit so gemacht?",
                      "sentence3": "Es geht mir gut, danke. Wie ist es mit Ihnen?",
                      "sentence4": "Ziemlich gut.",
                      "sentence5": "Dasselbe wie immer",
                      "sentence6": "Nicht so toll.",
                      "sentence7": "Könnte besser sein",
                      "sentence8": "kann mich nicht beklagen",
                      "sentence9": "Ich weiß das wirklich zu schätzen.",
                      "sentence10": "Ich bin wirklich dankbar",
                      "sentence11": "Das ist so lieb von dir.",
                      "sentence12": "Ich schulde dir etwas.",
                      "sentence13": "Kein Problem.",
                      "sentence14": "Keine Bange",
                      "sentence15": "Erwähne es nicht.",
                      "sentence16": "Gern geschehen.",
                      "sentence17": "Jederzeit.",
                      "sentence18": "Es war schön mit dir zu plaudern.",
                      "sentence19": "Wie auch immer, ich sollte loslegen.",
                      "sentence20": "Hast du irgendeine Idee?",
                      "sentence21": "Würdest du zufällig wissen, wo der Bahnhof ist?",
                      "sentence22": "Ich nehme nicht an, dass Sie wissen, wer der Präsident der USA ist.",
                      "sentence23": "Ich habe keine Ahnung.",
                      "sentence24": "Ich kann dir da nicht helfen.",
                      "sentence25": "Schlägt mich.",
                      "sentence26": "Ich bin mir nicht wirklich sicher.",
                      "sentence27": "Das habe ich mich auch gefragt.",
                      "sentence28": "Ich habe nie viel darüber nachgedacht.",
                      "sentence29": "Ich habe so oder so keine starken Gefühle.",
                      "sentence30": "Es macht keinen Unterschied für mich.",
                      "sentence31": "Ich habe keine Meinung dazu.",
                      "sentence32": "Genau.",
                      "sentence33": "Absolut.",
                      "sentence34": "Das ist wirklich wahr.",
                      "sentence35": "Das ist sicher.",
                      "sentence36": "Ich stimme zu 100% zu%",
                      "sentence37": "Ich könnte dir nicht mehr zustimmen.",
                      "sentence38": "Erzähl mir davon!",
                      "sentence39": "Ich sage!",
                      "sentence40": "Das nehme ich an.",
                      "sentence41": "Da bin ich mir nicht so sicher.",
                      "sentence42": "So sehe ich das nicht.",
                      "sentence43": "Nicht unbedingt",
                      "sentence44": "Das ist großartig!",
                      "sentence45": "Wie wundervoll!",
                      "sentence46": "Genial!",
                      "sentence47": "Ach nein…",
                      "sentence48": "Das ist furchtbar.",
                      "sentence49": "Du armer.",
                      "sentence50": "Es tut mir leid das zu hören.",
                      "sentence51": "Ich bin am Verhungern!",
                      "sentence52": "Lass uns einen Happen essen.",
                      "sentence53": "Wie wäre es heute Abend auswärts zu essen?"          
                    }
                }
              }
            });
          }
      }
};

const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
  },
  handle(handlerInput) {
    const speechText = i18next.t('welcome');

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard('Foreign language learning', speechText)
      .getResponse();
  },
};

function updateLabels(fromString, stringToReplace, value) {
    const regex = new RegExp('<' + stringToReplace + '>', 'g');
    return fromString.replace(regex, value) ;
}

function appendSentence(language) {
    let language = 'en-US';
    if(language === 'french' || language === 'französisch') {
        language = 'fr-FR';
    } else if(language === 'german' || language === 'allemand') {
        language = 'de-DE';
    }

    const sentenceNumber = (int)(Math.floor(Math.random() * 53) + 1);

    return SsmlUtils.escapeXmlCharacters('<lang xml:lang="fr-FR">' + i18nextSentences.t('sentence' + sentenceNumber) + '</lang>');
}

const LanguageLearnerIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'LanguageLearner';
  },
  handle(handlerInput) {
    const language = handlerInput.requestEnveloppe.request.intent.slots.language.value;
    const speechText = updateLabels(i18next.t('startLearning'), SELECTED_LANGUAGE, language) + appendSentence(language);;

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard('', speechText)
      .getResponse();
  },
};

const HelpIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const speechText = i18next.t('help');

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard('Langauge learner', speechText)
      .getResponse();
  },
};

const CancelAndStopIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const speechText = i18next.t('cancel');

    return handlerInput.responseBuilder
      .speak(speechText)
      .withSimpleCard('Language learner', speechText)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);

    return handlerInput.responseBuilder
      .speak('Sorry, I can\'t understand the command. Please say again.')
      .reprompt('Sorry, I can\'t understand the command. Please say again.')
      .getResponse();
  },
};
const skillBuilder = Alexa.SkillBuilders.custom();

//const skillBuilder = Alexa.SkillBuilders.standard();

exports.handler = skillBuilder
  .addRequestHandlers(
    LaunchRequestHandler,
    LanguageLearnerIntentHandler,
    HelpIntentHandler,
    CancelAndStopIntentHandler,
    SessionEndedRequestHandler
  )
  .addErrorHandlers(ErrorHandler)
  .addRequestInterceptors(TranslationService, TranslationSentences)
  .lambda();
